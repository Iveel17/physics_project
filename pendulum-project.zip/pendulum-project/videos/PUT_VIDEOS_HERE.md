# videos/

Put experiment clips here:
- The double-pendulum failure (hook) vs. the fixed single-plane swing.
- A timed 20-oscillation run.
