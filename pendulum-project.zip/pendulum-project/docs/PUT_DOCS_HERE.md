# docs/

Put supporting documents here:
- The pre-lab report (your own work).
- Notes on the reference paper (Nelson & Olsson 1986). Do NOT commit the copyrighted PDF to a
  public repo; cite it instead.
