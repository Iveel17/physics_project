# src/

The interactive website source is `index.html` at the repository root (so GitHub Pages
serves it automatically). All physics formulas are documented at the top of its <script> block.

Put analysis scripts or the calculation spreadsheet here (period averaging, g, error propagation).
