# images/

Put apparatus photos here:
- The pendulum setup, the cable-tie knots, the foam-board guide, the angle device (89.7 deg).
- A photo/scan of the handwritten data sheet.
