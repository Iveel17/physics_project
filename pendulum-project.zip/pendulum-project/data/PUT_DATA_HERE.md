# data/

Put the raw timing data here:
- A CSV or spreadsheet of the 20-oscillation trial times for each angle (5, 10, 15, 20 deg).
- Period calculations (T = time / 20) and the averaged values.
